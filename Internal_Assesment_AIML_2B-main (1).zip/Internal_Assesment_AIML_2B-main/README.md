#Internal Assessment

1.clone the file to your desktop
2.make the changes in "index.html" and "style.css file"

